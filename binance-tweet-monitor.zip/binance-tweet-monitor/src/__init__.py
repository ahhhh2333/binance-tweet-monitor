# -*- coding: utf-8 -*-
"""
币安推特监控机器人包
"""

__version__ = "2.0.0"
__author__ = "Binance Tweet Monitor"
__description__ = "自动监控币安推特账号的Alpha积分相关推文"